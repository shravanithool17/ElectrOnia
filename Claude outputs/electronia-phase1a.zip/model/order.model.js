import mongoose from 'mongoose';

// Every line is a snapshot taken at the moment the order was placed. Title and
// price are copied deliberately: if a vendor edits the product or its price
// later, a past order must still show what the customer actually bought.
const orderItemSchema = new mongoose.Schema(
  {
    productId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Product',
      required: true,
    },
    title: { type: String, required: true },
    // Integer paise — see docs/adr/0003.
    price: { type: Number, required: true, min: 0 },
    quantity: { type: Number, required: true, min: 1 },
    image: { type: String },
    // Which vendor owns this line. Lets a vendor be shown only the orders
    // that contain their own products.
    companyId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Company',
    },
  },
  { _id: false }
);

export const ORDER_STATUSES = ['Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled'];

const orderSchema = new mongoose.Schema(
  {
    customerId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Cutomers',
      required: true,
      index: true,
    },
    customerName: { type: String },
    customerEmail: { type: String },
    items: {
      type: [orderItemSchema],
      validate: {
        validator: (items) => Array.isArray(items) && items.length > 0,
        message: 'An order must contain at least one item',
      },
    },
    // Computed on the server from current product prices — never accepted
    // from the client. `totalAmount` is kept as the grand total so existing
    // clients keep working; `amounts` is the full breakdown an invoice needs.
    totalAmount: {
      type: Number,
      required: true,
      min: 0,
    },
    amounts: {
      itemsSubtotal: { type: Number, default: 0, min: 0 },
      discountTotal: { type: Number, default: 0, min: 0 },
      taxTotal: { type: Number, default: 0, min: 0 },
      shippingTotal: { type: Number, default: 0, min: 0 },
      grandTotal: { type: Number, default: 0, min: 0 },
    },
    couponCode: { type: String, uppercase: true, trim: true, default: null },
    // Snapshot of the address as it was at purchase. Editing the saved address
    // later must not rewrite where a past order went.
    addressId: { type: mongoose.Schema.Types.ObjectId, ref: 'Address', default: null },
    shippingAddress: {
      street: { type: String, required: true },
      city: { type: String, required: true },
      zipCode: { type: String, required: true },
      phone: { type: String, required: true },
    },
    paymentMethod: {
      type: String,
      enum: ['Card', 'UPI', 'COD'],
      default: 'COD',
    },
    status: {
      type: String,
      enum: ORDER_STATUSES,
      default: 'Pending',
      index: true,
    },
    // Append-only audit trail, so "order tracking" shows a real timeline
    // rather than just the latest value.
    statusHistory: [
      {
        status: { type: String, enum: ORDER_STATUSES, required: true },
        at: { type: Date, default: Date.now },
        byRole: { type: String },
        _id: false,
      },
    ],
    // Denormalised list of vendors with a line in this order, so the vendor
    // order query is a single indexed lookup instead of a scan over items.
    vendorIds: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Company',
        index: true,
      },
    ],
  },
  {
    timestamps: true,
  }
);

// "My orders, newest first" and "this vendor's orders, newest first".
orderSchema.index({ customerId: 1, createdAt: -1 });
orderSchema.index({ vendorIds: 1, createdAt: -1 });

const Order = mongoose.model('Order', orderSchema);
export default Order;
