ElectrOnia — Phase 1a: server-side cart, address book, coupons, pricing
=======================================================================

The device bridge dropped before I could write these to D:\ElectrOnia, so
here they are as a zip. Unzip it OVER your backend folder — every path below
is relative to D:\ElectrOnia\backend\.

  backend/
  ├─ lib/pricing.js              NEW  one pricing module: tax, shipping, coupons
  ├─ lib/coupons.data.js         NEW  WELCOME10, SUMMER20, STUDENT15, FREESHIP, FLAT500
  ├─ lib/seed.js                 REPLACES  now also seeds coupons
  ├─ model/cart.model.js         NEW
  ├─ model/address.model.js      NEW
  ├─ model/coupon.model.js       NEW
  ├─ model/couponRedemption.model.js  NEW
  ├─ model/order.model.js        REPLACES  adds amounts breakdown + couponCode
  ├─ modules/cart/               NEW  6 files
  ├─ modules/addresses/          NEW  5 files
  ├─ modules/checkout/           NEW  5 files
  ├─ routes/index.js             REPLACES  mounts /cart /addresses /checkout
  ├─ server.js                   REPLACES  adds cookie-parser
  ├─ package.json                REPLACES  adds cookie-parser dependency
  └─ tests/                      NEW  pricing (24 unit) + cart/checkout (integration)

THEN RUN:

  cd backend
  npm install            # cookie-parser is new
  npm run seed           # upserts the 5 coupons (products are untouched)
  npm run test:unit      # expect 54 passing
  npm run dev

NEW ENDPOINTS

  GET    /api/v1/cart
  POST   /api/v1/cart/items                        { productId, quantity }
  PATCH  /api/v1/cart/items/:productId             { quantity }
  DELETE /api/v1/cart/items/:productId
  POST   /api/v1/cart/items/:productId/save-for-later
  DELETE /api/v1/cart
  POST   /api/v1/cart/coupon                       { code }
  DELETE /api/v1/cart/coupon
  POST   /api/v1/cart/merge                        { guestToken }   [customer]

  GET    /api/v1/addresses                                          [customer]
  POST   /api/v1/addresses
  PATCH  /api/v1/addresses/:id
  POST   /api/v1/addresses/:id/default
  DELETE /api/v1/addresses/:id

  POST   /api/v1/checkout/quote                    { addressId? }   [customer]
  POST   /api/v1/checkout/place-order              { addressId?, paymentMethod? }

NOTHING IS BROKEN BY THIS
The old POST /api/orders still works, so the current frontend keeps
functioning until the cart UI is rewired.

PRICING RULES (all in lib/pricing.js)
  GST            18% default, per-line override supported
  Delivery       free at/above Rs 5,000, otherwise Rs 99 flat
  Coupons        percent (capped), fixed, or free_shipping
  Order of ops   subtotal - discount -> tax on the discounted value + shipping
  Shipping is decided on the PRE-discount subtotal, so a coupon cannot drag an
  order back under the free-delivery threshold.
