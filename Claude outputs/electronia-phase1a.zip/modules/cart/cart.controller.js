import crypto from 'crypto';
import { asyncHandler } from '../../lib/asyncHandler.js';
import { cartService } from './cart.service.js';

const GUEST_COOKIE = 'cartToken';

/**
 * Who owns this cart: the signed-in user, or an anonymous browser token.
 *
 * The guest token is issued server-side as a random value in an httpOnly
 * cookie. A predictable id would make every guest cart enumerable.
 */
export function resolveOwner(req, res) {
  if (req.user?.id) return { userId: req.user.id };

  let token = req.cookies?.[GUEST_COOKIE];

  if (!token) {
    token = crypto.randomUUID().replace(/-/g, '') + crypto.randomUUID().replace(/-/g, '');
    res.cookie(GUEST_COOKIE, token, {
      httpOnly: true,
      sameSite: 'lax',
      secure: req.secure,
      maxAge: 30 * 24 * 60 * 60 * 1000,
      path: '/',
    });
  }

  return { guestToken: token };
}

export const cartController = {
  get: asyncHandler(async (req, res) => {
    res.json(await cartService.get(resolveOwner(req, res)));
  }),

  addItem: asyncHandler(async (req, res) => {
    res.status(201).json(await cartService.addItem(resolveOwner(req, res), req.body));
  }),

  updateItem: asyncHandler(async (req, res) => {
    res.json(
      await cartService.updateQuantity(
        resolveOwner(req, res),
        req.params.productId,
        req.body.quantity
      )
    );
  }),

  removeItem: asyncHandler(async (req, res) => {
    res.json(await cartService.removeItem(resolveOwner(req, res), req.params.productId));
  }),

  toggleSaveForLater: asyncHandler(async (req, res) => {
    res.json(await cartService.toggleSaveForLater(resolveOwner(req, res), req.params.productId));
  }),

  clear: asyncHandler(async (req, res) => {
    res.json(await cartService.clear(resolveOwner(req, res)));
  }),

  merge: asyncHandler(async (req, res) => {
    // Only ever folds a guest cart into the authenticated caller's own cart —
    // the endpoint cannot name another user.
    res.json(await cartService.mergeGuestCart(req.user.id, req.body.guestToken));
  }),

  applyCoupon: asyncHandler(async (req, res) => {
    res.json(await cartService.applyCoupon(resolveOwner(req, res), req.body.code));
  }),

  removeCoupon: asyncHandler(async (req, res) => {
    res.json(await cartService.removeCoupon(resolveOwner(req, res)));
  }),
};
