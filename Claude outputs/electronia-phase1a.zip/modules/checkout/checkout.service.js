// modules/checkout/checkout.service.js
//
// Two entry points over the same pricing:
//
//   quote()      — reads the cart, prices it, writes nothing. Safe to call on
//                  every keystroke of the checkout form.
//   placeOrder() — reserves stock, creates the order, redeems the coupon and
//                  empties the cart.
//
// Prices, tax, shipping and discount all come from lib/pricing.js, the same
// module the cart uses, so the checkout total can never disagree with the cart.
import { ConflictError, ValidationError } from '../../lib/errors.js';
import { formatINR } from '../../lib/money.js';
import { priceOrder, amountToFreeShipping } from '../../lib/pricing.js';
import { productRepo } from '../catalog/product.repo.js';
import { orderRepo } from '../orders/order.repo.js';
import { toOrderDto } from '../orders/order.dto.js';
import { cartService } from '../cart/cart.service.js';
import { cartRepo } from '../cart/cart.repo.js';
import { addressService } from '../addresses/address.service.js';
import { couponService } from './coupon.service.js';

const money = (paise) => ({ amount: paise, label: formatINR(paise) });

async function loadPricedCart(owner) {
  const { cart, chargeable } = await cartService.getChargeable(owner);

  if (chargeable.length === 0) {
    throw new ValidationError('Your cart is empty.');
  }

  let coupon = null;
  if (cart.couponCode) {
    const resolved = await couponService.resolve(cart.couponCode, owner.userId);
    coupon = resolved.coupon;
  }

  const totals = priceOrder(
    chargeable.map((line) => ({ unitPrice: line.unitPrice, quantity: line.quantity })),
    coupon
  );

  return { cart, chargeable, coupon, totals };
}

/**
 * Conditional atomic decrement per line: the update only applies while stock
 * is still at least the requested quantity, so two simultaneous orders cannot
 * both take the last unit. Across lines this is not one transaction, so a
 * later failure compensates the earlier decrements.
 *
 * A multi-document transaction is the stronger guarantee and Atlas supports
 * it; this function is the seam where that swap happens.
 */
async function reserveStock(lines) {
  const reserved = [];

  for (const line of lines) {
    const updated = await productRepo.reserveStock(line.productId, line.quantity);
    if (!updated) {
      await Promise.all(
        reserved.map((r) => productRepo.releaseStock(r.productId, r.quantity))
      );
      return { ok: false, failedOn: line };
    }
    reserved.push(line);
  }

  return { ok: true };
}

export const checkoutService = {
  /** Priced preview. No writes, so it is safe to poll. */
  async quote(owner, addressId = null) {
    const { chargeable, totals, cart } = await loadPricedCart(owner);

    let address = null;
    let addressError = null;
    try {
      address = await addressService.resolveForCheckout(owner.userId, addressId);
    } catch (err) {
      addressError = err.message;
    }

    return {
      items: chargeable.map((line) => ({
        productId: line.productId,
        title: line.title,
        image: line.image,
        quantity: line.quantity,
        unitPrice: line.unitPrice,
        unitPriceLabel: formatINR(line.unitPrice),
        lineTotal: line.unitPrice * line.quantity,
        lineTotalLabel: formatINR(line.unitPrice * line.quantity),
      })),
      address,
      addressError,
      couponCode: cart.couponCode,
      summary: {
        itemsSubtotal: money(totals.itemsSubtotal),
        discountTotal: money(totals.discountTotal),
        taxTotal: money(totals.taxTotal),
        shippingTotal: money(totals.shippingTotal),
        grandTotal: money(totals.grandTotal),
        freeShipping: totals.freeShipping,
        amountToFreeShipping: money(amountToFreeShipping(totals.itemsSubtotal)),
        appliedCoupon: totals.appliedCoupon,
        couponError: totals.couponError,
      },
      payableNow: money(totals.grandTotal),
    };
  },

  async placeOrder(user, { addressId = null, paymentMethod = 'COD' } = {}) {
    const owner = { userId: user.id };
    const { cart, chargeable, coupon, totals } = await loadPricedCart(owner);

    const address = await addressService.resolveForCheckout(user.id, addressId);

    const reservation = await reserveStock(chargeable);
    if (!reservation.ok) {
      throw new ConflictError(
        'INSUFFICIENT_STOCK',
        `Not enough stock for "${reservation.failedOn.title}". Please reduce the quantity.`,
        { productId: reservation.failedOn.productId }
      );
    }

    try {
      const order = await orderRepo.create({
        customerId: user.id,
        customerName: user.name,
        customerEmail: user.email,
        items: chargeable.map((line) => ({
          productId: line.productId,
          title: line.title,
          price: line.unitPrice,
          quantity: line.quantity,
          image: line.image,
          companyId: line.companyId,
        })),
        totalAmount: totals.grandTotal,
        amounts: {
          itemsSubtotal: totals.itemsSubtotal,
          discountTotal: totals.discountTotal,
          taxTotal: totals.taxTotal,
          shippingTotal: totals.shippingTotal,
          grandTotal: totals.grandTotal,
        },
        couponCode: totals.appliedCoupon,
        addressId: address._id,
        // Snapshotted, not referenced.
        shippingAddress: {
          street: [address.line1, address.line2].filter(Boolean).join(', '),
          city: address.city,
          zipCode: address.pincode,
          phone: address.phone,
        },
        paymentMethod,
        status: 'Processing',
        statusHistory: [{ status: 'Processing', at: new Date(), byRole: 'system' }],
        vendorIds: [
          ...new Set(chargeable.map((l) => l.companyId).filter(Boolean).map(String)),
        ],
      });

      // After the order exists, so the redemption always points at a real order.
      if (coupon && totals.discountTotal > 0) {
        await couponService.redeem({
          code: coupon.code,
          userId: user.id,
          orderId: order._id,
          discountAmount: totals.discountTotal,
        });
      }

      // Only the purchased lines are cleared — anything saved for later stays.
      cart.items = cart.items.filter((item) => item.savedForLater);
      cart.couponCode = null;
      await cartRepo.save(cart);

      return toOrderDto(order.toObject());
    } catch (err) {
      // The order failed after stock was taken — put it back.
      await Promise.all(
        chargeable.map((l) => productRepo.releaseStock(l.productId, l.quantity))
      );
      throw err;
    }
  },
};
